package comunai.health.comunai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
