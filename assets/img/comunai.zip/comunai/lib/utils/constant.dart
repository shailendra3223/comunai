
class Constant {
  static const String message = 'success';
}