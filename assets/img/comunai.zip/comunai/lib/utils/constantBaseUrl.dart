
class ConstantBaseUrl{
  static const String  baseurl = "http://ec2-43-204-28-118.ap-south-1.compute.amazonaws.com:3000/";
}