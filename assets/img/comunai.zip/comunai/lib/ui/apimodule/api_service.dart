import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../../utils/constantBaseUrl.dart';
import '../client/dioClient.dart';
import '../model/login_response/login_response.dart';
import '../model/otp_page/otp_response_data.dart';
import '../model/signup/signup_response.dart';


class ApiService {
  static var client = http.Client();

  static final DioClient _dioClient = DioClient(

  );



  /*TODO------------------- Login Phone -------------------TODO*/
  static Future<LoginResponse> login(
      String phoneNumber) async {
    try {
      final body = {
        "phone_number": phoneNumber,
      };
      print('loginResponse $body');
      var response = await _dioClient
          .post('${ConstantBaseUrl.baseurl}v1/api/auth/users/login/otp', data: body);
      print('loginResponse $response');
      if (response["success"] == true) {
        print('success $response');
        return LoginResponse.fromJson(response);
      } else {
        throw Exception('Invalid mobile number!');
      }
    } on Error catch (e) {
      if (kDebugMode) {
        print('Error: $e');
      }
      throw Exception(e);
    }
  }

  /*TODO------------------- Login Phone Otp-------------------TODO*/
  static Future<OtpResponseData> loginOtp(
      String phoneNumber,String otpString) async {
    try {
      final body = {
        "phone_number": phoneNumber,
        'otp_string': otpString
      };
      print('otpResponse $body');
      var response = await _dioClient
          .post('${ConstantBaseUrl.baseurl}v1/api/auth/users/login/otp/verify', data: body);
      print('loginResponse $response');
      DioClient.token = response['token'];
    //  DioClient.tempToken = response['temp_token'];
        return OtpResponseData.fromJson(response);
    } on Error catch (e) {
      if (kDebugMode) {
        print('Error: $e');
      }
      throw Exception(e);
    }
  }

   /*TODO-------------------  Sign Up user List -------------------TODO*/
  static Future<SignupResonse> signUp(String first_name,String email_address,String date_of_birth,String gender) async {
    try {
      String myString ="\$2b\$12\$iZ3xXgHhQJzDnjcGLeiyquKtdnhc.XqI4HXWgFQ2qXmRnmbqmjnci";
      final body = {
        "temp_token": myString,
        "phone_number": "+917977170737",
        "first_name": first_name,
        "last_name": 'xyz',
        "email_address": email_address,
        "date_of_birth":date_of_birth,
        "gender": gender
      };
      print('signup $body');
      var response = await _dioClient
          .post('${ConstantBaseUrl.baseurl}v1/api/auth/users/register', data: body);
      print('signup $response');
       DioClient.token = response['token'];
      return SignupResonse.fromJson(response);
    } on Error catch (e) {
      if (kDebugMode) {
        print('Error: $e');
      }
      throw Exception(e);
    }
  }

  // /*TODO-------------------  GetNotificationCount -------------------TODO*/
  // static Future<CommonChatResponse> getNotification() async {
  //   try {
  //     final userId =
  //         await SharedPreferencesHelper().getString(PrefsConst.userId);
  //     var response = await _dioClient.get(
  //         '${ConstantBaseUrl.baseurl}chat/GetNotificationCount',
  //         queryParameters: {"userID": userId.toString()});
  //     print("getNotification $response");
  //     print(response["message"]);
  //     if (response["message"] == Constant.SUCCESS) {
  //       return CommonChatResponse.fromJson(response);
  //     } else {
  //       throw Exception('No data Found');
  //     }
  //   } on Error catch (e) {
  //     if (kDebugMode) {
  //       print('Error: $e');
  //     }
  //     throw Exception(e);
  //   }
  // }
  //
  // /*TODO------------------- Forward Chat user List -------------------TODO*/
  // static Future<ForwardChatUserResponse> getForwardCharUserList() async {
  //   try {
  //     final userId =
  //         await SharedPreferencesHelper().getString(PrefsConst.userId);
  //     var response = await _dioClient.get(
  //         '${ConstantBaseUrl.baseurl}chat/GetMobileUserList?userId=${userId.toString()}');
  //     print("userList $response");
  //     print(response["message"]);
  //     if (response["message"] == Constant.SUCCESS) {
  //       return ForwardChatUserResponse.fromJson(response);
  //     } else {
  //       throw Exception('No data Found');
  //     }
  //   } on Error catch (e) {
  //     if (kDebugMode) {
  //       print('Error: $e');
  //     }
  //     throw Exception(e);
  //   }
  // }
  //
  // /*TODO------------------- Forward Chat Data user Wise -------------------TODO*/
  // static Future<ChatDataUserWise> chatUserWise(dynamic chatUserId) async {
  //   print(chatUserId);
  //   try {
  //     final body = {
  //       'userId': await SharedPreferencesHelper().getString(PrefsConst.userId),
  //       "pageNumber": "1",
  //       "chatUserId": chatUserId,
  //     };
  //     var response = await _dioClient
  //         .post('${ConstantBaseUrl.baseurl}chat/GetChatUserWise', data: body);
  //     print('GetChatUserWise ');
  //     if (response["message"] == Constant.SUCCESS) {
  //       return ChatDataUserWise.fromJson(response);
  //     } else {
  //       throw Exception('Failed To Update Device Id!');
  //     }
  //   } on Error catch (e) {
  //     if (kDebugMode) {
  //       print('Error: $e');
  //     }
  //     throw Exception(e);
  //   }
  // }
  //
  // /*TODO------------------- UserProfile -------------------TODO*/
  // static Future<UserProfile> geUserProfile() async {
  //   try {
  //     final userId =
  //         await SharedPreferencesHelper().getString(PrefsConst.userId);
  //     var response = await _dioClient.get(
  //         '${ConstantBaseUrl.baseurl}chat/GetMobileProfileImg',
  //         queryParameters: {"userID": userId.toString()});
  //     if (kDebugMode) {
  //       print("hdasdasdad " + response);
  //     }
  //     if (response["message"] == Constant.SUCCESS) {
  //       return UserProfile.fromJson(response);
  //     } else {
  //       throw Exception('No data Found');
  //     }
  //   } on Error catch (e) {
  //     if (kDebugMode) {
  //       print('Error: $e');
  //     }
  //     throw Exception(e);
  //   }
  // }
  //
  // /*TODO------------------- updateDeviceId -------------------TODO*/
  // static Future<UpdateDeviceId> updateDeviceId() async {
  //   try {
  //     final body = {
  //       'userId': await SharedPreferencesHelper().getString(PrefsConst.userId),
  //       "deviceId": "",
  //     };
  //     var response = await _dioClient
  //         .post('${ConstantBaseUrl.baseurl}chat/UpdateDeviceId', data: body);
  //     if (kDebugMode) {
  //       print('updateDeviceId $response');
  //     }
  //     if (response["message"] == Constant.SUCCESS) {
  //       return UpdateDeviceId.fromJson(response);
  //     } else {
  //       throw Exception('Failed To Update Device Id!');
  //     }
  //   } on Error catch (e) {
  //     if (kDebugMode) {
  //       print('Error: $e');
  //     }
  //     throw Exception(e);
  //   }
  // }
  //
  // /*TODO------------------- updateProfilePost -------------------TODO*/
  // static Future<UpdateProfilePost> updateProfilePost(File file) async {
  //   String fileName = file.path.split('/').last;
  //
  //   try {
  //     /*final body= {
  //        "UserId": await SharedPreferencesHelper().getString(PrefsConst.userId),
  //        "FileData": file
  //      };*/
  //     FormData formData = FormData.fromMap({
  //       'UserId': await SharedPreferencesHelper().getString(PrefsConst.userId),
  //       'FileData': await MultipartFile.fromFile(file.path, filename: fileName)
  //     });
  //
  //     var response = await _dioClient.post(
  //         '${ConstantBaseUrl.baseurl}chat/UpdateMobileProfileImg',
  //         data: formData);
  //     if (kDebugMode) {
  //       print('FileDataList $response');
  //     }
  //     if (response["message"] == Constant.SUCCESS) {
  //       return UpdateProfilePost.fromJson(response);
  //     } else {
  //       throw Exception('Failed To Update Device Id!');
  //     }
  //   } on Error catch (e) {
  //     if (kDebugMode) {
  //       print('Error: $e');
  //     }
  //     throw Exception(e);
  //   }
  // }
  //
  // /*TODO Save Chat TODO*/
  // static Future<SaveChatResponse> saveChatData(int userChatId, String message,
  //     {List<File>? file}) async {
  //   /*   String fileName = "";
  //   if(file!=null){
  //     fileName = file!.path.split('/').last;
  //   }*/
  //   FormData formData;
  //   try {
  //     formData = FormData.fromMap({
  //       'UserId': await SharedPreferencesHelper().getString(PrefsConst.userId),
  //       "ChatUserId": userChatId,
  //       "Message": message,
  //     });
  //     for (File element in file ?? []) {
  //       formData.files.add(
  //           MapEntry("FileData", await MultipartFile.fromFile(element.path)));
  //     }
  //
  //     print('saveChatData ${formData.fields}');
  //     /* else{
  //        formData =  FormData.fromMap({
  //         'UserId': await SharedPreferencesHelper().getString(PrefsConst.userId),
  //         // 'FileData':await MultipartFile.fromFile(file.path,
  //         //     filename: fileName),
  //         // "ChatId":chatId,
  //         "ChatUserId":userChatId,
  //         "Message":message,
  //       });
  //     }*/
  //
  //     var response = await _dioClient
  //         .post('${ConstantBaseUrl.baseurl}chat/SaveChat', data: formData);
  //     print('saveChatData $response');
  //     if (response["message"] == Constant.SUCCESS) {
  //       return SaveChatResponse.fromJson(response);
  //     } else {
  //       throw Exception('Failed To Update Device Id!');
  //     }
  //   }
  //   on Error catch (e) {
  //     if (kDebugMode) {
  //       print('Error: $e');
  //     }
  //     throw Exception(e);
  //   }
  // }
  //
  // /*TODO------------------- deleteAllChat -------------------TODO*/
  // static Future<DeleteAllChatResponse> deleteAllChat(String chatUserId) async {
  //   try {
  //     final body = {
  //       'userId': await SharedPreferencesHelper().getString(PrefsConst.userId),
  //       'chatUserId': chatUserId,
  //     };
  //     print(body.toString());
  //     var response = await _dioClient
  //         .post('${ConstantBaseUrl.baseurl}chat/DeleteAllChat', data: body);
  //     if (response["message"] == Constant.SUCCESS) {
  //       return DeleteAllChatResponse.fromJson(response);
  //     } else {
  //       throw Exception('Failed To Update Device Id!');
  //     }
  //   } on Error catch (e) {
  //     print('Error: $e');
  //     throw Exception(e);
  //   }
  // }
  //
  // /*TODO------------------- updateDeviceId -------------------TODO*/
  // static Future<CommonChatResponse> deleteChat(String chatId) async {
  //   try {
  //     final body = {
  //       'userId': await SharedPreferencesHelper().getString(PrefsConst.userId),
  //       "ChatId": chatId.toString(),
  //     };
  //     var response = await _dioClient
  //         .post('${ConstantBaseUrl.baseurl}chat/DeleteChat', data: body);
  //
  //     if (response["message"] == Constant.SUCCESS) {
  //       return CommonChatResponse.fromJson(response);
  //     } else {
  //       throw Exception('Failed To Update Device Id!');
  //     }
  //   } on Error catch (e) {
  //     print('Error: $e');
  //     throw Exception(e);
  //   }
  // }
  //
  // /*TODO------------------- updateDeviceId -------------------TODO*/
  // static Future<CommonChatResponse> mobileForwardChat(
  //     int chatId, dynamic chatUserId) async {
  //   try {
  //     final body = {
  //       'userId': await SharedPreferencesHelper().getString(PrefsConst.userId),
  //       "messageId": chatId.toString(),
  //       "chatUserId": chatUserId,
  //     };
  //     print("dfssfdfdsfsd " + body.toString());
  //     var response = await _dioClient
  //         .post('${ConstantBaseUrl.baseurl}chat/MobileForwandChat', data: body);
  //
  //     if (response["message"] == Constant.SUCCESS) {
  //       return CommonChatResponse.fromJson(response);
  //     } else {
  //       throw Exception('Failed To Update Device Id!');
  //     }
  //   } on Error catch (e) {
  //     print('Error: $e');
  //     throw Exception(e);
  //   }
  // }
}
