import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFF00ADEF);
  static const Color secondaryColor = Color(0xFFFF5722);
  static const Color textColor = Color(0xFF747997);
  static const Color btnColor = Color(0xFF4166C6);
// Define your other colors here
}
